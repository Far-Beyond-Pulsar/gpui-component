pub fn begin_play() {
    print_string(Default::default());
    if node_9a6bcef6_8c5b_482d_9ac4_686db736b5e0_result { print_string (Default :: default ()) ; } else { }
}
